-- =====================================================================
-- SGEA - Sistema de Gerenciamento de Eventos Acadêmicos (Cenário 4)
-- 01_schema.sql: criação das tabelas, restrições e gatilhos
-- SGBD: PostgreSQL (testado para uso no Supabase)
-- =====================================================================

-- Recria o esquema do zero (use com cuidado: apaga os dados).
DROP TABLE IF EXISTS presenca              CASCADE;
DROP TABLE IF EXISTS inscricao             CASCADE;
DROP TABLE IF EXISTS atividade_palestrante CASCADE;
DROP TABLE IF EXISTS palestrante           CASCADE;
DROP TABLE IF EXISTS atividade             CASCADE;
DROP TABLE IF EXISTS participante          CASCADE;
DROP TABLE IF EXISTS evento                CASCADE;

-- ---------------------------------------------------------------------
-- Evento
-- ---------------------------------------------------------------------
CREATE TABLE evento (
    id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome         VARCHAR(150) NOT NULL,
    descricao    TEXT,
    data_inicio  DATE         NOT NULL,
    data_fim     DATE         NOT NULL,
    local        VARCHAR(150),
    -- RN01: a data de fim não pode ser anterior à de início
    CONSTRAINT ck_evento_periodo CHECK (data_fim >= data_inicio)
);

-- ---------------------------------------------------------------------
-- Participante
-- ---------------------------------------------------------------------
CREATE TABLE participante (
    id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome         VARCHAR(150) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    cpf          CHAR(11)     NOT NULL,
    instituicao  VARCHAR(150),
    -- RN12: CPF e e-mail únicos
    CONSTRAINT uq_participante_email UNIQUE (email),
    CONSTRAINT uq_participante_cpf   UNIQUE (cpf),
    CONSTRAINT ck_participante_cpf   CHECK (cpf ~ '^[0-9]{11}$')
);

-- ---------------------------------------------------------------------
-- Atividade (pertence a um único evento: RN03)
-- ---------------------------------------------------------------------
CREATE TABLE atividade (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    evento_id          BIGINT       NOT NULL REFERENCES evento (id),
    titulo             VARCHAR(150) NOT NULL,
    tipo               VARCHAR(20)  NOT NULL,
    data_hora_inicio   TIMESTAMP    NOT NULL,
    data_hora_fim      TIMESTAMP    NOT NULL,
    sala               VARCHAR(80),
    vagas_totais       INTEGER      NOT NULL,
    carga_horaria      INTEGER      NOT NULL,
    CONSTRAINT ck_atividade_tipo    CHECK (tipo IN ('Palestra', 'Minicurso', 'Mesa-redonda', 'Seminario')),
    CONSTRAINT ck_atividade_horario CHECK (data_hora_fim > data_hora_inicio),
    CONSTRAINT ck_atividade_vagas   CHECK (vagas_totais > 0),
    CONSTRAINT ck_atividade_carga   CHECK (carga_horaria > 0),
    -- Permite que presenca referencie (atividade, evento) em conjunto
    CONSTRAINT uq_atividade_evento  UNIQUE (id, evento_id)
);

-- ---------------------------------------------------------------------
-- Palestrante e vínculo N:N com atividade (RN05)
-- ---------------------------------------------------------------------
CREATE TABLE palestrante (
    id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome         VARCHAR(150) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    instituicao  VARCHAR(150),
    CONSTRAINT uq_palestrante_email UNIQUE (email)
);

CREATE TABLE atividade_palestrante (
    atividade_id   BIGINT NOT NULL REFERENCES atividade   (id) ON DELETE CASCADE,
    palestrante_id BIGINT NOT NULL REFERENCES palestrante (id),
    PRIMARY KEY (atividade_id, palestrante_id)
);

-- ---------------------------------------------------------------------
-- Inscrição: liga participante a evento, com situação (RN06, RN07, RN08)
-- ---------------------------------------------------------------------
CREATE TABLE inscricao (
    id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    participante_id BIGINT      NOT NULL REFERENCES participante (id),
    evento_id       BIGINT      NOT NULL REFERENCES evento (id),
    data_inscricao  DATE        NOT NULL DEFAULT CURRENT_DATE,
    situacao        VARCHAR(10) NOT NULL DEFAULT 'Confirmada',
    -- RN08: toda inscrição tem uma situação definida
    CONSTRAINT ck_inscricao_situacao CHECK (situacao IN ('Confirmada', 'Cancelada')),
    -- RN07: uma inscrição por participante em cada evento
    CONSTRAINT uq_inscricao_participante_evento UNIQUE (participante_id, evento_id),
    -- Permite que presenca referencie (inscricao, evento) em conjunto
    CONSTRAINT uq_inscricao_evento UNIQUE (id, evento_id)
);

-- ---------------------------------------------------------------------
-- Presença: liga atividade e inscrição (RN09, RN10, RN11)
-- A coluna evento_id, com as duas chaves estrangeiras compostas, garante
-- que a atividade e a inscrição pertencem ao MESMO evento.
-- ---------------------------------------------------------------------
CREATE TABLE presenca (
    id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    atividade_id  BIGINT    NOT NULL,
    inscricao_id  BIGINT    NOT NULL,
    evento_id     BIGINT    NOT NULL,
    data_hora     TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_presenca_atividade FOREIGN KEY (atividade_id, evento_id)
        REFERENCES atividade (id, evento_id),
    CONSTRAINT fk_presenca_inscricao FOREIGN KEY (inscricao_id, evento_id)
        REFERENCES inscricao (id, evento_id),
    -- RN11: uma presença por participante em cada atividade
    CONSTRAINT uq_presenca_atividade_inscricao UNIQUE (atividade_id, inscricao_id)
);

-- Índices nas chaves estrangeiras mais consultadas
CREATE INDEX idx_atividade_evento ON atividade (evento_id);
CREATE INDEX idx_inscricao_evento ON inscricao (evento_id);
CREATE INDEX idx_presenca_inscricao ON presenca (inscricao_id);

-- =====================================================================
-- Gatilhos para regras que restrições simples não expressam
-- =====================================================================

-- RN10: só pode ter presença quem tem inscrição Confirmada no evento.
CREATE OR REPLACE FUNCTION fn_valida_presenca() RETURNS trigger AS $$
DECLARE
    v_situacao VARCHAR(10);
BEGIN
    SELECT situacao INTO v_situacao FROM inscricao WHERE id = NEW.inscricao_id;
    IF v_situacao IS DISTINCT FROM 'Confirmada' THEN
        RAISE EXCEPTION 'Presença recusada: a inscrição % não está Confirmada.', NEW.inscricao_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_valida_presenca
    BEFORE INSERT ON presenca
    FOR EACH ROW EXECUTE FUNCTION fn_valida_presenca();

-- RN04: o horário da atividade deve estar dentro do período do evento.
CREATE OR REPLACE FUNCTION fn_valida_horario_atividade() RETURNS trigger AS $$
DECLARE
    v_inicio DATE;
    v_fim    DATE;
BEGIN
    SELECT data_inicio, data_fim INTO v_inicio, v_fim FROM evento WHERE id = NEW.evento_id;
    IF NEW.data_hora_inicio::date < v_inicio OR NEW.data_hora_fim::date > v_fim THEN
        RAISE EXCEPTION 'Atividade fora do período do evento (% a %).', v_inicio, v_fim;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_valida_horario_atividade
    BEFORE INSERT OR UPDATE ON atividade
    FOR EACH ROW EXECUTE FUNCTION fn_valida_horario_atividade();
