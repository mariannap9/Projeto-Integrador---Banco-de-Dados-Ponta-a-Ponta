-- =====================================================================
-- SGEA - 02_dados_exemplo.sql
-- Dados fictícios para testar o esquema e as consultas.
-- Execute DEPOIS de 01_schema.sql, em um banco recém-criado (os ids
-- das tabelas começam em 1 e são usados diretamente abaixo).
-- =====================================================================

-- Eventos (ids 1 e 2)
INSERT INTO evento (nome, descricao, data_inicio, data_fim, local) VALUES
('Semana Acadêmica de Computação', 'Palestras e minicursos sobre tecnologia.', '2026-10-05', '2026-10-07', 'Campus Uberlândia Centro'),
('Seminário de Pesquisa e Extensão', 'Apresentação de projetos de pesquisa e extensão.', '2026-11-16', '2026-11-17', 'Auditório Central');

-- Participantes (ids 1 a 8)
INSERT INTO participante (nome, email, cpf, instituicao) VALUES
('Ana Souza',      'ana.souza@exemplo.com',      '11111111111', 'IFTM'),
('Bruno Lima',     'bruno.lima@exemplo.com',     '22222222222', 'IFTM'),
('Carla Mendes',   'carla.mendes@exemplo.com',   '33333333333', 'UFU'),
('Diego Ferreira', 'diego.ferreira@exemplo.com', '44444444444', 'IFTM'),
('Elisa Rocha',    'elisa.rocha@exemplo.com',    '55555555555', 'UFU'),
('Fábio Costa',    'fabio.costa@exemplo.com',    '66666666666', 'IFTM'),
('Gabriela Alves', 'gabriela.alves@exemplo.com', '77777777777', 'Externa'),
('Heitor Nunes',   'heitor.nunes@exemplo.com',   '88888888888', 'IFTM');

-- Palestrantes (ids 1 a 5)
INSERT INTO palestrante (nome, email, instituicao) VALUES
('Dra. Marta Oliveira', 'marta.oliveira@exemplo.com', 'UFU'),
('Prof. Ricardo Pinto', 'ricardo.pinto@exemplo.com', 'IFTM'),
('Dr. Paulo Andrade',   'paulo.andrade@exemplo.com',  'USP'),
('Profa. Sandra Reis',  'sandra.reis@exemplo.com',    'IFTM'),
('Lucas Martins',       'lucas.martins@exemplo.com',  'Empresa Tech');

-- Atividades (ids 1 a 6; 1 a 4 no evento 1, 5 e 6 no evento 2)
INSERT INTO atividade (evento_id, titulo, tipo, data_hora_inicio, data_hora_fim, sala, vagas_totais, carga_horaria) VALUES
(1, 'Abertura e Palestra Magna',      'Palestra',     '2026-10-05 19:00', '2026-10-05 21:00', 'Auditório', 100, 2),
(1, 'Introdução a Banco de Dados',    'Minicurso',    '2026-10-06 14:00', '2026-10-06 18:00', 'Lab 1',      20, 4),
(1, 'Inteligência Artificial no Dia a Dia', 'Palestra', '2026-10-06 19:00', '2026-10-06 21:00', 'Auditório', 100, 2),
(1, 'Carreiras em Tecnologia',        'Mesa-redonda', '2026-10-07 19:00', '2026-10-07 21:00', 'Auditório', 100, 2),
(2, 'Metodologia da Pesquisa',        'Palestra',     '2026-11-16 19:00', '2026-11-16 21:00', 'Auditório', 80, 2),
(2, 'Extensão e Comunidade',          'Mesa-redonda', '2026-11-17 19:00', '2026-11-17 21:00', 'Auditório', 80, 2);

-- Palestrantes por atividade (uma atividade pode ter vários)
INSERT INTO atividade_palestrante (atividade_id, palestrante_id) VALUES
(1, 1),
(2, 2),
(3, 1), (3, 3),
(4, 4), (4, 5), (4, 2),
(5, 3),
(6, 4), (6, 1);

-- Inscrições (ids 1 a 11). Evento 1: 6 confirmadas e 1 cancelada. Evento 2: 4 confirmadas.
INSERT INTO inscricao (participante_id, evento_id, data_inscricao, situacao) VALUES
(1, 1, '2026-09-20', 'Confirmada'),  -- id 1
(2, 1, '2026-09-21', 'Confirmada'),  -- id 2
(3, 1, '2026-09-22', 'Confirmada'),  -- id 3
(4, 1, '2026-09-23', 'Confirmada'),  -- id 4
(5, 1, '2026-09-24', 'Confirmada'),  -- id 5
(6, 1, '2026-09-25', 'Confirmada'),  -- id 6
(7, 1, '2026-09-26', 'Cancelada'),   -- id 7
(1, 2, '2026-11-01', 'Confirmada'),  -- id 8
(2, 2, '2026-11-02', 'Confirmada'),  -- id 9
(3, 2, '2026-11-03', 'Confirmada'),  -- id 10
(8, 2, '2026-11-04', 'Confirmada');  -- id 11

-- Presenças (atividade_id, inscricao_id, evento_id)
INSERT INTO presenca (atividade_id, inscricao_id, evento_id, data_hora) VALUES
-- Atividade 1 (evento 1): 6 presenças
(1, 1, 1, '2026-10-05 19:05'), (1, 2, 1, '2026-10-05 19:07'), (1, 3, 1, '2026-10-05 19:10'),
(1, 4, 1, '2026-10-05 19:12'), (1, 5, 1, '2026-10-05 19:15'), (1, 6, 1, '2026-10-05 19:20'),
-- Atividade 2 (evento 1, minicurso): 3 presenças
(2, 1, 1, '2026-10-06 14:05'), (2, 2, 1, '2026-10-06 14:08'), (2, 3, 1, '2026-10-06 14:10'),
-- Atividade 3 (evento 1): 5 presenças
(3, 1, 1, '2026-10-06 19:05'), (3, 2, 1, '2026-10-06 19:06'), (3, 3, 1, '2026-10-06 19:08'),
(3, 4, 1, '2026-10-06 19:10'), (3, 5, 1, '2026-10-06 19:12'),
-- Atividade 4 (evento 1): 4 presenças
(4, 1, 1, '2026-10-07 19:05'), (4, 2, 1, '2026-10-07 19:07'), (4, 3, 1, '2026-10-07 19:09'),
(4, 6, 1, '2026-10-07 19:11'),
-- Atividade 5 (evento 2): 4 presenças
(5, 8, 2, '2026-11-16 19:05'), (5, 9, 2, '2026-11-16 19:06'), (5, 10, 2, '2026-11-16 19:08'),
(5, 11, 2, '2026-11-16 19:10'),
-- Atividade 6 (evento 2): 2 presenças
(6, 8, 2, '2026-11-17 19:05'), (6, 9, 2, '2026-11-17 19:07');
