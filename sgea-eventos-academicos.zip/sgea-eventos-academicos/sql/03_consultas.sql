-- =====================================================================
-- SGEA - 03_consultas.sql
-- Consultas que respondem às perguntas gerenciais do projeto.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Quantos participantes estão inscritos em cada evento?
--    (apenas inscrições Confirmadas; eventos sem inscritos aparecem com 0)
-- ---------------------------------------------------------------------
SELECT e.nome AS evento,
       COUNT(i.id) AS inscritos
FROM evento e
LEFT JOIN inscricao i
       ON i.evento_id = e.id AND i.situacao = 'Confirmada'
GROUP BY e.id, e.nome
ORDER BY inscritos DESC;

-- ---------------------------------------------------------------------
-- 2) Quais atividades possuem maior participação?
--    (participação = número de presenças registradas na atividade)
-- ---------------------------------------------------------------------
SELECT a.titulo,
       e.nome AS evento,
       COUNT(p.id) AS presencas
FROM atividade a
JOIN evento e ON e.id = a.evento_id
LEFT JOIN presenca p ON p.atividade_id = a.id
GROUP BY a.id, a.titulo, e.nome
ORDER BY presencas DESC, a.titulo;

-- ---------------------------------------------------------------------
-- 3) Quais participantes atingiram determinada frequência em um evento?
--    Frequência = presenças / total de atividades do evento (em %).
--    Altere o evento e a frequência mínima na CTE "parametros".
-- ---------------------------------------------------------------------
WITH parametros AS (
    SELECT 1 AS evento_id, 75.0 AS freq_minima
),
total_atividades AS (
    SELECT COUNT(*) AS total
    FROM atividade a
    JOIN parametros pr ON a.evento_id = pr.evento_id
)
SELECT pa.nome,
       COUNT(p.id) AS presencas,
       ta.total    AS atividades_do_evento,
       ROUND(100.0 * COUNT(p.id) / NULLIF(ta.total, 0), 1) AS frequencia_percentual
FROM inscricao i
JOIN parametros pr       ON i.evento_id = pr.evento_id
JOIN participante pa     ON pa.id = i.participante_id
CROSS JOIN total_atividades ta
LEFT JOIN presenca p     ON p.inscricao_id = i.id
WHERE i.situacao = 'Confirmada'
GROUP BY pa.id, pa.nome, ta.total, pr.freq_minima
HAVING 100.0 * COUNT(p.id) / NULLIF(ta.total, 0) >= pr.freq_minima
ORDER BY frequencia_percentual DESC, pa.nome;

-- ---------------------------------------------------------------------
-- 4) Quais palestrantes conduzem mais atividades?
-- ---------------------------------------------------------------------
SELECT pl.nome,
       COUNT(ap.atividade_id) AS atividades
FROM palestrante pl
LEFT JOIN atividade_palestrante ap ON ap.palestrante_id = pl.id
GROUP BY pl.id, pl.nome
ORDER BY atividades DESC, pl.nome;

-- ---------------------------------------------------------------------
-- 5) Qual a taxa de ocupação das vagas de cada atividade?
--    Taxa = presenças / vagas totais (em %).
-- ---------------------------------------------------------------------
SELECT a.titulo,
       a.vagas_totais,
       COUNT(p.id) AS presencas,
       ROUND(100.0 * COUNT(p.id) / a.vagas_totais, 1) AS ocupacao_percentual
FROM atividade a
LEFT JOIN presenca p ON p.atividade_id = a.id
GROUP BY a.id, a.titulo, a.vagas_totais
ORDER BY ocupacao_percentual DESC;

-- ---------------------------------------------------------------------
-- 6) Quantas inscrições canceladas cada evento teve?
-- ---------------------------------------------------------------------
SELECT e.nome AS evento,
       COUNT(i.id) AS canceladas
FROM evento e
LEFT JOIN inscricao i
       ON i.evento_id = e.id AND i.situacao = 'Cancelada'
GROUP BY e.id, e.nome
ORDER BY canceladas DESC;
