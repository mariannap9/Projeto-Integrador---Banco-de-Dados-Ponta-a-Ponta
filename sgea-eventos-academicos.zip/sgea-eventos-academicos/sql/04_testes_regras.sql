-- =====================================================================
-- SGEA - 04_testes_regras.sql
-- Cada comando abaixo DEVE FALHAR, provando que a regra é protegida pelo
-- banco. Rode um de cada vez no SQL Editor e confira a mensagem de erro.
-- (Depende de 01_schema.sql e 02_dados_exemplo.sql.)
-- =====================================================================

-- RN07: segunda inscrição do mesmo participante no mesmo evento
INSERT INTO inscricao (participante_id, evento_id) VALUES (1, 1);

-- RN08: inscrição com situação fora da lista (Confirmada/Cancelada)
INSERT INTO inscricao (participante_id, evento_id, situacao) VALUES (8, 1, 'Pendente');

-- RN10: presença de participante com inscrição Cancelada (inscrição 7)
INSERT INTO presenca (atividade_id, inscricao_id, evento_id) VALUES (1, 7, 1);

-- RN06/RN09: presença de inscrição do evento 2 em atividade do evento 1
INSERT INTO presenca (atividade_id, inscricao_id, evento_id) VALUES (1, 8, 1);

-- RN11: presença repetida do mesmo participante na mesma atividade
INSERT INTO presenca (atividade_id, inscricao_id, evento_id) VALUES (1, 1, 1);

-- RN04: atividade fora do período do evento 1 (05 a 07/10/2026)
INSERT INTO atividade (evento_id, titulo, tipo, data_hora_inicio, data_hora_fim, vagas_totais, carga_horaria)
VALUES (1, 'Atividade fora do período', 'Palestra', '2026-12-01 19:00', '2026-12-01 21:00', 50, 2);

-- RN01: evento com data de fim anterior à de início
INSERT INTO evento (nome, data_inicio, data_fim) VALUES ('Evento inválido', '2026-12-10', '2026-12-01');

-- RN12: CPF repetido
INSERT INTO participante (nome, email, cpf) VALUES ('Duplicado', 'outro@exemplo.com', '11111111111');
